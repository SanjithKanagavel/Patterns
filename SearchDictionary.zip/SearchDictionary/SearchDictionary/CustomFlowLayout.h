//
//  CustomFlowLayout.h
//  SearchDictionary
//
//  Created by Sanjith J K on 09/11/16.
//  Copyright © 2016 Sanjith Kanagavel. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface CustomFlowLayout : UICollectionViewFlowLayout
@end
