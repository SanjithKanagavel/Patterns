//
//  Favourite.m
//  SearchDictionary
//
//  Created by Sanjith J K on 13/11/16.
//  Copyright © 2016 Sanjith Kanagavel. All rights reserved.
//

#import "Favourite.h"

@implementation Favourite

@end
